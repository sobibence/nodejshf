/*
* Lekerdezi az adott :gazdiid-u gazdit a db-bol, es a res.locals.cica-ba rakja
*/

module.exports = function(objectrepository){
    return function (req, res, next) {
        return next();
    };
};