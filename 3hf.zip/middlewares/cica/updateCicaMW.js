/*
* Frissiti a POST adatokbol a cicat, majd redirektel a gazdijanak edit oldalra.
*/

module.exports = function(objectrepository){
    return function (req, res, next) {
        return next();
    };
};