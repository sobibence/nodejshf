/*
* Letrehoz egy cicat a POST adatokbol, majd redirektel a gazdi edit oldalara.
*/

module.exports = function(objectrepository){
    return function (req, res, next) {
        return next();
    };
};