/*
* Lekerdezi az adott :cicaid-u cicat a db-bol, es a res.locals.cica-ba rakja
*/

module.exports = function(objectrepository){
    return function (req, res, next) {
        return next();
    };
};