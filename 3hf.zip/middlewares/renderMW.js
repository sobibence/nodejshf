/*
* Kirendereli a megadott html nezetetet templatinggel.
*/

module.exports = function(objectrepository){
    return function (req, res, next) {
        return next();
    };
};