/*
* Frissiti a POST adatokbol a gazdit, majd redirektel a gazdi edit oldalra.
*/

module.exports = function(objectrepository){
    return function (req, res, next) {
        return next();
    };
};